<?php
// PHP 8.1+. Set environment variables in hosting; no credentials belong in HTML.
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function finish(int $status, array $body): never {http_response_code($status); echo json_encode($body); exit;}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') finish(405, ['ok'=>false,'error'=>'Method not allowed.']);
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && (parse_url($origin, PHP_URL_HOST) !== ($_SERVER['SERVER_NAME'] ?? ''))) finish(403, ['ok'=>false,'error'=>'Invalid request origin.']);
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 65536) finish(413, ['ok'=>false,'error'=>'Request is too large.']);
$raw=file_get_contents('php://input', false, null, 0, 65537);
if ($raw===false || strlen($raw)>65536) finish(413,['ok'=>false,'error'=>'Request is too large.']);
$data=json_decode($raw,true);
if (!is_array($data)) finish(400,['ok'=>false,'error'=>'Invalid request.']);
$kind=$data['Kind']??'';
if (!in_array($kind,['services','speaking','workshop','guide','contact','interest'],true)) finish(422,['ok'=>false,'error'=>'Invalid request type.']);
if (!empty($data['Website Verification'])) finish(422,['ok'=>false,'error'=>'Request could not be verified.']);
unset($data['Website Verification']);
$required=['First Name','Email'];
if ($kind!=='guide') $required[]='Last Name';
if (in_array($kind,['services','speaking','workshop'],true)) $required=array_merge($required,['Organization','Role','Country']);
$byKind=[
 'services'=>['Service','Challenge','Outcome','Timeframe','Delivery Preference','Location','Investment','Decision Role'],
 'speaking'=>['Event Name','Event Date','Event Location','Event Format','Event Type','Audience Size','Speaking Format','Topic','Outcome','Investment'],
 'workshop'=>['Participant Count','Challenge','Outcome','Delivery Preference','Time Zone','Location','Duration','Investment'],
 'contact'=>['Topic','Subject','Message'],
 'interest'=>['Program'],
 'guide'=>[]
];
$required=array_merge($required,$byKind[$kind]);
if ($kind!=='guide' && ($data['Privacy']??'')!=='accepted') finish(422,['ok'=>false,'error'=>'Please acknowledge the Privacy Policy.']);
foreach ($required as $name) {if (!isset($data[$name]) || !is_string($data[$name]) || trim($data[$name])==='') finish(422,['ok'=>false,'error'=>'Please complete: '.$name]);}
if (!filter_var($data['Email'],FILTER_VALIDATE_EMAIL)) finish(422,['ok'=>false,'error'=>'Please enter a valid email address.']);
foreach($data as $key=>$value){
 if(strlen((string)$key)>100 || (!is_scalar($value) && !is_array($value))) finish(422,['ok'=>false,'error'=>'Invalid form field.']);
 if(is_array($value)){if(count($value)>30)finish(422,['ok'=>false,'error'=>'Too many selections.']);foreach($value as $v){if(!is_string($v)||strlen($v)>1000)finish(422,['ok'=>false,'error'=>'Invalid selection.']);}}
 elseif(is_string($value)&&strlen($value)>12000)finish(422,['ok'=>false,'error'=>'A field is too long.']);
}
// Webhook must validate conditional fields and enforce server-side rate limits/spam protection.
// Only acknowledge after the configured service has durably accepted the request.
$url=getenv('ARIFF_FORM_WEBHOOK')?:'';
$secret=getenv('ARIFF_FORM_SECRET')?:'';
if(!filter_var($url,FILTER_VALIDATE_URL)||parse_url($url,PHP_URL_SCHEME)!=='https'||$secret==='') finish(503,['ok'=>false,'error'=>'Online enquiries are not yet available. Please contact info@ariffconsulting.com.']);
if(!function_exists('curl_init'))finish(503,['ok'=>false,'error'=>'The enquiry service is temporarily unavailable. Please contact info@ariffconsulting.com.']);
$map=['services'=>'Services Lead','speaking'=>'Speaking Lead','workshop'=>'Workshop Lead','guide'=>'ARIFF Guide Lead','contact'=>'Contact Enquiry','interest'=>'Program Interest'];
$serviceLabels=['Keynote Speaking'=>'Speaking Lead','Leadership Workshop'=>'Workshop Lead','Executive Decision Lab'=>'Executive Lab Lead','Enterprise Implementation'=>'Enterprise Lead','Executive Consulting'=>'Advisory Lead','Education / University Program'=>'Education Lead','Bulk Books'=>'Bulk Book Lead','Partnership / Collaboration'=>'Partnership Lead','Custom Program'=>'Custom Program Lead'];
$data['Email']=strtolower(trim($data['Email']));
$data['Marketing']=($data['Marketing']??false)===true;
$data['Labels']=[$map[$kind]];
if($kind==='services'&&isset($serviceLabels[$data['Service']]))$data['Labels'][]=$serviceLabels[$data['Service']];
$data['Received At']=gmdate('c');
$data['Request ID']=bin2hex(random_bytes(16));
$data['Consent Version']='2026-11-05';
$ch=curl_init($url);
curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($data),CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$secret],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>25,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS]);
$result=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
$reply=is_string($result)?json_decode($result,true):null;
if($code<200||$code>=300||!is_array($reply)||($reply['accepted']??false)!==true)finish(502,['ok'=>false,'error'=>'We could not confirm receipt of your request. Please retry or contact info@ariffconsulting.com.']);
finish(200,['ok'=>true]);
