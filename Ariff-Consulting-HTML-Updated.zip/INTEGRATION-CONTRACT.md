# Form integration contract

The PHP relay sends a JSON object using `Authorization: Bearer ARIFF_FORM_SECRET` to `ARIFF_FORM_WEBHOOK`. It does not redirect or report success unless the service returns HTTP 2xx with `{"accepted":true}`. Never return `accepted:true` before durable acceptance. Queue emails reliably and retry failed jobs. Enforce authentication, rate limits, anti-spam checks, field allowlists, topic-specific required fields and length limits at the webhook. Apply a per-IP rate limit at the hosting/WAF before launch. Do not log secrets or full request bodies into public server logs.

Fields include `Kind`, `First Name`, `Last Name`, `Email`, `Marketing` (boolean), `Privacy` (accepted for non-guide requests), `Labels`, `Source` (array when selected), form-specific context, `Received At`, `Request ID`, `Consent Version`, `Page` and `Referrer`. Headers, labels and success destinations are owned by the backend/frontend, not supplied to an open redirect. Do not treat client-supplied source values as verified attribution.

1. Store the submission privately with an explicit retention policy and access control. Use email-normalized contact upsert to avoid duplicates, preserving previous consent history. Do not interpret an unchecked opt-in as an automatic withdrawal of consent from a pre-existing subscriber; record the choice for this specific request. Record actual consent timestamp, text/version, channel and source. Only add marketing subscriptions when the optional consent is explicitly true and all applicable requirements are satisfied. Request ID is a transport receipt, not a payment or enrollment ID.
2. Apply universal and service-specific `Labels`; store role, audience, requested outcomes, timeframe, investment and source as separate attributes. Services may also be labeled Education Lead, Advisory Lead, Partnership Lead etc. Classify specific contact support topics appropriately.
3. Notify `info@ariffconsulting.com` with a concise summary and secure CRM link. Send a transactional receipt to the validated requestor email without a public calendar or promise of fit/availability. Queue retries and monitor delivery failure. Configure sender authentication and suppression/unsubscribe handling for marketing separately.
4. Guide request: subject `Your ARIFF Method™ Executive Guide Is Ready`; send the requested guide link `https://ariffconsulting.com/assets/ariff-guide.pdf`. For personal access, implement token links and protected storage in the delivery service; the supplied static asset is public. Do not add the contact to marketing without explicit opt-in.
5. Workshop: confirmation describes Review → Sponsor Conversation → Customize → Proposal. Speaking: Review → Assess Fit & Availability → Discovery → Recommendation. Generic services: Review → Assess Fit → Discovery → Recommendation. Contact: confirm the topic and route support to the appropriate owner.
6. Payment and Teachable webhooks must be authenticated against the platform's current official verification mechanism; never enroll users from a frontend query parameter or thank-you page. Successful verified payment grants the correct product, creates/updates the customer and suppresses the corresponding sales sequence. Failed payments grant no enrollment. Course completion and certificates remain with Teachable according to configured criteria.

Return examples:

```json
{"accepted":true}
```

Return a non-2xx status for a failure. Do not echo private submissions or provider errors to the visitor. Tests should cover valid/invalid inputs, webhook outage, retry behavior, duplicate-contact upsert, spam/rate limiting, yes/no marketing preference, guide delivery, receipt and internal notification. Test with staging credentials and authorized addresses before production.
